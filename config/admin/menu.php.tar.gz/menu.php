<?php

	/*
 	 *
	 *
	 * */
	return  [
		[
			'href' => '/admin',
			'name' => 'Главная',
			'icon' => 'fa fa-home',

		],

		[
			'href' => '/admin/partners',
			'name' => 'Партнёры',
			'icon' => 'fa fa-users',

		],

	];